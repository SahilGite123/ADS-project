// Event listener for route planning
document.getElementById('route-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const fromCity = document.getElementById('from-city').value;
    const toCity = document.getElementById('to-city').value;

    // Make an AJAX request to get the shortest path
    fetch(`/api/travel/shortest-path?start=${fromCity}&end=${toCity}`)
        .then(response => response.json())
        .then(data => {
            if (data.path) {
                document.getElementById('path-result').innerHTML = `Path: ${data.path}, Distance: ${data.distance} km`;
            } else {
                document.getElementById('path-result').innerHTML = 'No path found.';
            }

            // Fetch hotel recommendations for the route
            fetch(`/api/travel/accommodations?start=${fromCity}&end=${toCity}`)
                .then(response => response.json())
                .then(hotels => {
                    const accommodationList = document.getElementById('accommodation-list');
                    accommodationList.innerHTML = '';
                    if (hotels.length > 0) {
                        hotels.forEach(hotel => {
                            const listItem = document.createElement('li');
                            listItem.textContent = hotel;
                            accommodationList.appendChild(listItem);
                        });
                    } else {
                        accommodationList.innerHTML = 'No hotels found for this route.';
                    }
                })
                .catch(error => {
                    console.error('Error fetching hotel recommendations:', error);
                    document.getElementById('accommodation-list').innerHTML = 'Error fetching hotel recommendations.';
                });
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('path-result').innerHTML = 'Error fetching shortest path.';
        });
});

// Event listener for fetching activity suggestions
document.getElementById('fetch-activities').addEventListener('click', function() {
    const activities = ['Sightseeing', 'Hiking', 'Museum Visit', 'Beach Day'];
    const activityList = document.getElementById('activity-list');
    activityList.innerHTML = '';
    activities.forEach(activity => {
        const listItem = document.createElement('li');
        listItem.textContent = activity;
        activityList.appendChild(listItem);
    });
});
