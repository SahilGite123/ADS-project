package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/travel")
public class Controller {

    @Autowired
    private TravelService travelService;

    @GetMapping("/shortest-path")
    public Map<String, Object> getShortestPath(@RequestParam String start, @RequestParam String end) {
        return travelService.findShortestPath(start, end);
    }

@GetMapping("/accommodations")
public List<String> getHotelRecommendations(@RequestParam String start, @RequestParam String end) {
    return travelService.getHotelRecommendationsAlongRoute(start, end);
}

}
