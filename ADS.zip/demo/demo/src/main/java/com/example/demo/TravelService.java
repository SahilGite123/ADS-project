package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class TravelService {

    private static final String[] cities = {"City A", "City B", "City C", "City D", "City E"};
    private static final Map<String, Map<String, Integer>> distances = new HashMap<>();

    private final RecommendationService recommendationService;

    @Autowired
    public TravelService(RecommendationService recommendationService) {
        this.recommendationService = recommendationService;
        initializeDistances();
    }

    private void initializeDistances() {
        distances.put("City A", new HashMap<>());
        distances.get("City A").put("City B", 5);
        distances.get("City A").put("City C", 10);

        distances.put("City B", new HashMap<>());
        distances.get("City B").put("City A", 5);
        distances.get("City B").put("City D", 15);
        distances.get("City B").put("City C", 20);

        distances.put("City C", new HashMap<>());
        distances.get("City C").put("City A", 10);
        distances.get("City C").put("City B", 20);
        distances.get("City C").put("City D", 30);
        distances.get("City C").put("City E", 25);

        distances.put("City D", new HashMap<>());
        distances.get("City D").put("City B", 15);
        distances.get("City D").put("City C", 30);
        distances.get("City D").put("City E", 35);

        distances.put("City E", new HashMap<>());
        distances.get("City E").put("City C", 25);
        distances.get("City E").put("City D", 35);
    }

    public List<String> getHotelRecommendationsAlongRoute(String start, String end) {
        Map<String, Object> pathResult = findShortestPath(start, end);
        String path = (String) pathResult.get("path");

        if (path == null || start.equals(end)) {
            return Collections.emptyList();
        }

        return recommendationService.getHotelRecommendationsAlongRoute(path);
    }

    public Map<String, Object> findShortestPath(String start, String end) {
        Map<String, Object> result = new HashMap<>();

        if (start.equals(end)) {
            result.put("path", "Start and end cities are the same!");
            return result;
        }

        Map<String, Integer> shortestDistances = new HashMap<>();
        Map<String, String> previousCities = new HashMap<>();
        PriorityQueue<String> priorityQueue = new PriorityQueue<>(Comparator.comparingInt(shortestDistances::get));

        for (String city : cities) {
            if (city.equals(start)) {
                shortestDistances.put(city, 0);
            } else {
                shortestDistances.put(city, Integer.MAX_VALUE);
            }
            priorityQueue.add(city);
        }

        while (!priorityQueue.isEmpty()) {
            String currentCity = priorityQueue.poll();
            if (currentCity.equals(end)) break;

            Map<String, Integer> neighbors = distances.get(currentCity);
            if (neighbors != null) {
                for (String neighbor : neighbors.keySet()) {
                    int newDist = shortestDistances.get(currentCity) + neighbors.get(neighbor);
                    if (newDist < shortestDistances.get(neighbor)) {
                        priorityQueue.remove(neighbor);
                        shortestDistances.put(neighbor, newDist);
                        previousCities.put(neighbor, currentCity);
                        priorityQueue.add(neighbor);
                    }
                }
            }
        }

        StringBuilder path = new StringBuilder();
        String step = end;

        if (previousCities.containsKey(end)) {
            path.append(end);
            while (!step.equals(start)) {
                step = previousCities.get(step);
                path.insert(0, step + " -> ");
            }
            result.put("path", path.toString());
            result.put("distance", shortestDistances.get(end));
        } else {
            result.put("path", "No path found between " + start + " and " + end);
        }

        return result;
    }
}
