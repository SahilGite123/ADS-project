package com.example.demo;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class RecommendationService {

    private static final Map<String, List<String>> hotelRecommendations = new HashMap<>();

    public RecommendationService() {
        initializeHotelRecommendations();
    }

    // Initialize hotel recommendations based on city routes
    private void initializeHotelRecommendations() {
        hotelRecommendations.put("City A-City B", Arrays.asList("Hotel A", "Hotel B"));
        hotelRecommendations.put("City B-City D", Arrays.asList("Hotel C", "Hotel D"));
        hotelRecommendations.put("City C-City E", Arrays.asList("Hotel E"));
        hotelRecommendations.put("City A-City C", Arrays.asList("Hotel F"));
    }

    // Function to get hotel recommendations along the full route (including intermediate cities)
    public List<String> getHotelRecommendationsAlongRoute(String path) {
        if (path == null) {
            return Collections.emptyList();
        }

        List<String> hotelsAlongRoute = new ArrayList<>();
        String[] citiesInPath = path.split(" -> ");

        // For each pair of adjacent cities in the path, get hotels
        for (int i = 0; i < citiesInPath.length - 1; i++) {
            String city1 = citiesInPath[i];
            String city2 = citiesInPath[i + 1];
            String routeKey1 = city1 + "-" + city2;
            String routeKey2 = city2 + "-" + city1;

            if (hotelRecommendations.containsKey(routeKey1)) {
                hotelsAlongRoute.addAll(hotelRecommendations.get(routeKey1));
            } else if (hotelRecommendations.containsKey(routeKey2)) {
                hotelsAlongRoute.addAll(hotelRecommendations.get(routeKey2));
            }
        }
        return hotelsAlongRoute;
    }
}
